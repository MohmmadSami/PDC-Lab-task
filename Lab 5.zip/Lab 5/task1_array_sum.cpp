#include <iostream>
#include <vector>
#include <chrono>
#include <omp.h>

using namespace std;
using namespace chrono;

int main()
{
    int n = 100000000;   // Size of array
    vector<int> arr(n,1); // Create array and initialize all elements to 1

    long long sequential_sum = 0;
    long long parallel_sum = 0;

    // ---------------- SEQUENTIAL VERSION ----------------
    // Start timer
    auto start_seq = high_resolution_clock::now();

    // Normal loop to compute sum
    for(int i = 0; i < n; i++)
    {
        sequential_sum += arr[i];
    }

    // Stop timer
    auto end_seq = high_resolution_clock::now();

    auto seq_time = duration_cast<milliseconds>(end_seq - start_seq);

    // ---------------- PARALLEL VERSION ----------------
    // Start timer
    auto start_par = high_resolution_clock::now();

    // Parallel loop using OpenMP
    // reduction is used to safely combine partial sums from multiple threads
    #pragma omp parallel for reduction(+:parallel_sum)
    for(int i = 0; i < n; i++)
    {
        parallel_sum += arr[i];
    }

    // Stop timer
    auto end_par = high_resolution_clock::now();

    auto par_time = duration_cast<milliseconds>(end_par - start_par);

    // ---------------- OUTPUT ----------------
    cout << "Sequential Sum: " << sequential_sum << endl;
    cout << "Parallel Sum: " << parallel_sum << endl;

    cout << "Sequential Time: " << seq_time.count() << " ms" << endl;
    cout << "Parallel Time: " << par_time.count() << " ms" << endl;

    // Speedup calculation
    double speedup = (double)seq_time.count() / par_time.count();

    cout << "Speedup Achieved: " << speedup << endl;

    return 0;
}