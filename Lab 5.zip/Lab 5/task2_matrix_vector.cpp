#include <iostream>
#include <chrono>
#include <omp.h>

using namespace std;
using namespace chrono;

int main()
{
    int rows = 1000;
    int cols = 1000;

    int matrix[1000][1000];
    int vec[1000];
    int seq_result[1000] = {0};
    int par_result[1000] = {0};

    // ---------------- INITIALIZATION ----------------
    // Initialize vector and matrix with value 1
    for(int i = 0; i < cols; i++)
    {
        vec[i] = 1;
    }

    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            matrix[i][j] = 1;
        }
    }

    // ---------------- SEQUENTIAL VERSION ----------------
    auto start_seq = high_resolution_clock::now();

    // Matrix-vector multiplication
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            seq_result[i] += matrix[i][j] * vec[j];
        }
    }

    auto end_seq = high_resolution_clock::now();

    auto seq_time = duration_cast<milliseconds>(end_seq - start_seq);

    // ---------------- PARALLEL VERSION ----------------
    auto start_par = high_resolution_clock::now();

    // Parallelizing outer loop using OpenMP
    #pragma omp parallel for
    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j < cols; j++)
        {
            par_result[i] += matrix[i][j] * vec[j];
        }
    }

    auto end_par = high_resolution_clock::now();

    auto par_time = duration_cast<milliseconds>(end_par - start_par);

    // ---------------- OUTPUT ----------------
    cout << "Sequential Time: " << seq_time.count() << " ms" << endl;
    cout << "Parallel Time: " << par_time.count() << " ms" << endl;

    // Speedup calculation
    double speedup = (double)seq_time.count() / par_time.count();

    cout << "Speedup Achieved: " << speedup << endl;

    return 0;
}