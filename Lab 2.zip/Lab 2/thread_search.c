#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int *array;
int target;
int array_size;

typedef struct {
    int start;
    int end;
} ThreadData;

void* search(void* arg) {
    ThreadData* data = (ThreadData*)arg;

    int* found_index = malloc(sizeof(int));
    *found_index = -1;

    for(int i = data->start; i < data->end; i++) {
        if(array[i] == target) {
            *found_index = i;
            break;
        }
    }

    pthread_exit(found_index);
}

int main() {
    int num_threads;

    printf("Enter array size: ");
    scanf("%d", &array_size);

    array = malloc(array_size * sizeof(int));

    printf("Enter array elements:\n");
    for(int i = 0; i < array_size; i++) {
        scanf("%d", &array[i]);
    }

    printf("Enter value to search: ");
    scanf("%d", &target);

    printf("Enter number of threads: ");
    scanf("%d", &num_threads);

    pthread_t threads[num_threads];
    ThreadData thread_data[num_threads];

    int part = array_size / num_threads;

    // Create threads
    for(int i = 0; i < num_threads; i++) {
        thread_data[i].start = i * part;
        thread_data[i].end = (i == num_threads - 1) ? array_size : (i + 1) * part;

        pthread_create(&threads[i], NULL, search, &thread_data[i]);
    }

    // Collect results
    for(int i = 0; i < num_threads; i++) {
        int* result;
        pthread_join(threads[i], (void**)&result);

        if(*result != -1) {
            printf("Value found at index %d\n", *result);
        }

        free(result);
    }

    free(array);
    return 0;
}