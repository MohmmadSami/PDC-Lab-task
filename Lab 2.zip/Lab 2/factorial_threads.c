#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void* factorial(void* arg) {
    int num = *(int*)arg;

    long long* result = malloc(sizeof(long long));
    *result = 1;

    for(int i = 1; i <= num; i++) {
        *result *= i;
    }

    pthread_exit(result);
}

int main() {
    int n;

    printf("Enter number of values: ");
    scanf("%d", &n);

    pthread_t threads[n];
    int numbers[n];
    long long* results[n];

    // Take input
    for(int i = 0; i < n; i++) {
        printf("Enter number %d: ", i+1);
        scanf("%d", &numbers[i]);
    }

    // Create threads
    for(int i = 0; i < n; i++) {
        pthread_create(&threads[i], NULL, factorial, &numbers[i]);
    }

    // Collect results
    for(int i = 0; i < n; i++) {
        pthread_join(threads[i], (void**)&results[i]);
        printf("Factorial of %d = %lld\n", numbers[i], *results[i]);
        free(results[i]);
    }

    return 0;
}