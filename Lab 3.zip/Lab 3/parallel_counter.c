#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define NUM_THREADS 4
#define INCREMENTS 1000000

long long counter = 0;
pthread_mutex_t mutex;

// Function WITHOUT mutex
void* increment_without_mutex(void* arg) {
    for(int i = 0; i < INCREMENTS; i++) {
        counter++;   // Race condition
    }
    return NULL;
}

// Function WITH mutex
void* increment_with_mutex(void* arg) {
    for(int i = 0; i < INCREMENTS; i++) {
        pthread_mutex_lock(&mutex);
        counter++;
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS];
    clock_t start, end;
    double time_taken;

    // ---------- Without Mutex ----------
    counter = 0;
    start = clock();

    for(int i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i], NULL, increment_without_mutex, NULL);

    for(int i = 0; i < NUM_THREADS; i++)
        pthread_join(threads[i], NULL);

    end = clock();
    time_taken = (double)(end - start) / CLOCKS_PER_SEC;

    printf("Without Mutex:\n");
    printf("Counter = %lld\n", counter);
    printf("Time = %f seconds\n\n", time_taken);

    // ---------- With Mutex ----------
    counter = 0;
    pthread_mutex_init(&mutex, NULL);

    start = clock();

    for(int i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i], NULL, increment_with_mutex, NULL);

    for(int i = 0; i < NUM_THREADS; i++)
        pthread_join(threads[i], NULL);

    end = clock();
    time_taken = (double)(end - start) / CLOCKS_PER_SEC;

    printf("With Mutex:\n");
    printf("Counter = %lld\n", counter);
    printf("Time = %f seconds\n", time_taken);

    pthread_mutex_destroy(&mutex);

    return 0;
}