#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_THREADS 3

int balance = 1000;
pthread_mutex_t mutex;

// Deposit function
void* deposit(void* arg) {
    int amount = *(int*)arg;

    pthread_mutex_lock(&mutex);

    balance += amount;
    printf("Deposited: %d | New Balance: %d\n", amount, balance);

    pthread_mutex_unlock(&mutex);

    return NULL;
}

// Withdraw function
void* withdraw(void* arg) {
    int amount = *(int*)arg;

    pthread_mutex_lock(&mutex);

    if(balance >= amount) {
        balance -= amount;
        printf("Withdrawn: %d | New Balance: %d\n", amount, balance);
    } else {
        printf("Insufficient Balance for withdrawal of %d\n", amount);
    }

    pthread_mutex_unlock(&mutex);

    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS * 2];
    pthread_mutex_init(&mutex, NULL);

    int deposits[NUM_THREADS] = {200, 300, 150};
    int withdrawals[NUM_THREADS] = {100, 500, 400};

    // Create deposit threads
    for(int i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i], NULL, deposit, &deposits[i]);

    // Create withdraw threads
    for(int i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i + NUM_THREADS], NULL, withdraw, &withdrawals[i]);

    // Join all threads
    for(int i = 0; i < NUM_THREADS * 2; i++)
        pthread_join(threads[i], NULL);

    printf("\nFinal Balance: %d\n", balance);

    pthread_mutex_destroy(&mutex);

    return 0;
}