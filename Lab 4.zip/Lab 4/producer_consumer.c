#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define BUFFER_SIZE 5
#define NUM_PRODUCERS 2
#define NUM_CONSUMERS 2

int buffer[BUFFER_SIZE];
int count = 0;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t buffer_not_full = PTHREAD_COND_INITIALIZER;
pthread_cond_t buffer_not_empty = PTHREAD_COND_INITIALIZER;

// Producer Thread
void* producer(void* arg) {
    int id = *(int*)arg;

    while (1) {
        sleep(1);  // simulate production time

        pthread_mutex_lock(&mutex);

        // Wait if buffer is full
        while (count == BUFFER_SIZE) {
            pthread_cond_wait(&buffer_not_full, &mutex);
        }

        int item = rand() % 100;
        buffer[count++] = item;

        printf("Producer %d produced: %d\n", id, item);

        // Signal consumer
        pthread_cond_signal(&buffer_not_empty);

        pthread_mutex_unlock(&mutex);
    }
}

// Consumer Thread
void* consumer(void* arg) {
    int id = *(int*)arg;

    while (1) {
        sleep(2);  // simulate consuming time

        pthread_mutex_lock(&mutex);

        // Wait if buffer empty
        while (count == 0) {
            pthread_cond_wait(&buffer_not_empty, &mutex);
        }

        int item = buffer[--count];
        printf("Consumer %d consumed: %d\n", id, item);

        // Signal producer
        pthread_cond_signal(&buffer_not_full);

        pthread_mutex_unlock(&mutex);
    }
}

int main() {
    pthread_t producers[NUM_PRODUCERS];
    pthread_t consumers[NUM_CONSUMERS];

    int p_ids[NUM_PRODUCERS];
    int c_ids[NUM_CONSUMERS];

    // Create producer threads
    for (int i = 0; i < NUM_PRODUCERS; i++) {
        p_ids[i] = i;
        pthread_create(&producers[i], NULL, producer, &p_ids[i]);
    }

    // Create consumer threads
    for (int i = 0; i < NUM_CONSUMERS; i++) {
        c_ids[i] = i;
        pthread_create(&consumers[i], NULL, consumer, &c_ids[i]);
    }

    // Join threads (runs forever)
    for (int i = 0; i < NUM_PRODUCERS; i++)
        pthread_join(producers[i], NULL);

    for (int i = 0; i < NUM_CONSUMERS; i++)
        pthread_join(consumers[i], NULL);

    return 0;
}