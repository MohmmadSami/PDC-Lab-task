#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_VEHICLES 5

int light_green = 0;  // 0 = Red, 1 = Green

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t light_cond = PTHREAD_COND_INITIALIZER;

// Traffic Light Controller Thread
void* traffic_light(void* arg) {
    while (1) {
        sleep(5);  // Red for 5 seconds

        pthread_mutex_lock(&mutex);

        light_green = 1;
        printf("\nTraffic Light: GREEN\n");

        pthread_cond_broadcast(&light_cond); // Wake all vehicles

        pthread_mutex_unlock(&mutex);

        sleep(5);  // Green for 5 seconds

        pthread_mutex_lock(&mutex);

        light_green = 0;
        printf("\nTraffic Light: RED\n");

        pthread_mutex_unlock(&mutex);
    }
}

// Vehicle Thread
void* vehicle(void* arg) {
    int id = *(int*)arg;

    pthread_mutex_lock(&mutex);

    while (!light_green) {
        printf("Vehicle %d waiting at RED light\n", id);
        pthread_cond_wait(&light_cond, &mutex);
    }

    printf("Vehicle %d passing through GREEN light\n", id);

    pthread_mutex_unlock(&mutex);

    return NULL;
}

int main() {
    pthread_t light_thread;
    pthread_t vehicles[NUM_VEHICLES];
    int ids[NUM_VEHICLES];

    // Create traffic light controller
    pthread_create(&light_thread, NULL, traffic_light, NULL);

    sleep(1); // Small delay

    // Create vehicle threads
    for (int i = 0; i < NUM_VEHICLES; i++) {
        ids[i] = i;
        pthread_create(&vehicles[i], NULL, vehicle, &ids[i]);
        sleep(1);
    }

    for (int i = 0; i < NUM_VEHICLES; i++)
        pthread_join(vehicles[i], NULL);

    pthread_join(light_thread, NULL);

    return 0;
}