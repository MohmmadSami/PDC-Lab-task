#include <iostream>
#include <pthread.h>
#include <cmath>

using namespace std;

// Pointer for dynamic array
int* arr;

// Structure to pass data to threads
struct ThreadData {
    int number;
    int index;
};

// Function to check if a number is prime
bool isPrime(int num) {
    if (num < 2) return false;
    for (int i = 2; i <= sqrt(num); i++) {
        if (num % i == 0) return false;
    }
    return true;
}

// Thread function to check prime
void* checkPrime(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    int num = data->number;
    int idx = data->index;

    if (isPrime(num)) {
        cout << "Element " << num << " at index " << idx << " is Prime.\n";
    } else {
        cout << "Element " << num << " at index " << idx << " is Not Prime.\n";
    }

    pthread_exit(NULL);
}

int main() {
    int n;

    // Take array size input
    cout << "Enter the size of the array: ";
    cin >> n;

    arr = new int[n]; // Allocate dynamic array

    // Take array elements input
    cout << "Enter " << n << " elements:\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    pthread_t threads[n];        // Array of threads
    ThreadData threadData[n];    // Data for each thread

    // Create threads
    for (int i = 0; i < n; i++) {
        threadData[i].number = arr[i];
        threadData[i].index = i;
        pthread_create(&threads[i], NULL, checkPrime, (void*)&threadData[i]);
    }

    // Join threads
    for (int i = 0; i < n; i++) {
        pthread_join(threads[i], NULL);
    }

    // Free dynamically allocated array
    delete[] arr;

    return 0;
}