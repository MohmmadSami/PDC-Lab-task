#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    FILE *inputFile, *outputFile;
    int number, sum = 0;

    if (argc != 3)
    {
        printf("Usage: %s <input_file> <output_file>\n", argv[0]);
        return 1;
    }

    inputFile = fopen(argv[1], "r");
    if (inputFile == NULL)
    {
        perror("Error opening input file");
        return 1;
    }

    while (fscanf(inputFile, "%d", &number) != EOF)
    {
        sum += number;
    }

    fclose(inputFile);

    outputFile = fopen(argv[2], "w");
    if (outputFile == NULL)
    {
        perror("Error opening output file");
        return 1;
    }

    fprintf(outputFile, "Sum = %d\n", sum);
    fclose(outputFile);

    printf("Sum written to %s\n", argv[2]);
    return 0;
}
